# Bunch Extension for Consensus-based Clustering 

To run: 
`java -cp Bunch.jar bunch.RunBunch <dependency graph: file in .csv format> <consensus groups: file in .txt format> <population size: integer> <output dir: directory path>`

Inputs:
- The `dependency graph` must be a CSV file. Specifically, each line represents a dependency and must be formatted as follows: `[caller class],[callee class],[dependency weight]`.   
- The `consensus groups` contains all the entities in the dependency graph that you wish to lock together during the clustering process. Each line represents a consensus group and must be formatted as follows: `SS('GROUP_NAME'.ss) = entity0, entity1, entity2...`. 
  - Note: if you wish to define NO consensus groups, then input an empty txt file. 
- The `population size` is parameter used to optimize the clustering. The higher the population size, the better the clustering result. 
- The `output dir` is the directory path where the results will be saved. 
