import sys
import csv
import numpy as np
from sklearn.cluster import KMeans


def write_to_rsf_file(arch_result, name):
    with open(name, "w") as f:
        writer = csv.writer(f, delimiter=" ")
        writer.writerows(arch_result)


def convert_bunch_to_rsf(bunch_graph_name):
    entityRelations = []
    with open(bunch_graph_name, 'r') as bunchFile:
        lines = bunchFile.readlines()
        for line in lines:
            clusterNameSeparatedFromEntities = line.split(' = ')
            [ clusterName, entities ] = clusterNameSeparatedFromEntities

            clusterName = clusterName.replace('SS(', '')
            clusterName = clusterName.replace(')', '')

            entities = entities.split(', ')
            for entity in entities:
                entity = entity.replace('\n','')
                entityRelations.append((clusterName, entity))

    return entityRelations


def run_k_means_clustering(dependency_graph, gt_file, num_of_clusters):
    feature_matrix, class_names = transform_graph_to_matrix(dependency_graph)
    number_of_clusters = int(num_of_clusters)

    X = np.array(feature_matrix)

    kmeans = KMeans(n_clusters=number_of_clusters, random_state=0).fit(X)
    labels = kmeans.labels_

    arch_result = []
    for i, label in enumerate(labels):
        arch_result.append(["contain", label, class_names[i]])

    return arch_result


def transform_graph_to_matrix(dependency_graph):
    class_names = get_all_unique_file_names(dependency_graph)
    dependency_map = {}

    for classA in class_names:
        dependency_map[classA] = {}
        for classB in class_names:
            dependency_map[classA][classB] = 0

    with open(dependency_graph, "r") as f:
        reader = csv.reader(f)
        for dep in reader:
            caller = dep[0]
            callee = dep[1]
            weight = float(dep[2])

            dependency_map[caller][callee] += weight

    feature_matrix = []
    for classA in class_names:
        feature = []
        for classB in class_names:
            if classA == classB:
                feature.append(0)
            else:
                feature.append(dependency_map[classA][classB] + dependency_map[classB][classA])

        feature_matrix.append(feature)

    m = np.matrix(feature_matrix).flatten()
    avg = np.sum(m) / np.count_nonzero(m)
    std = np.std(m)

    inverse_feature_matrix = []
    for classA in class_names:
        feature = []
        for classB in class_names:
            w = dependency_map[classA][classB] + dependency_map[classB][classA]
            if classA == classB:
                feature.append(0)
            elif w == 0:
                feature.append(0)
            else:
                w = (w - avg) / std
                feature.append(1 - sigmoid(w))

        inverse_feature_matrix.append(feature)

    return inverse_feature_matrix, class_names


def sigmoid(x):
    return np.exp(-np.logaddexp(0, -x))


def get_all_unique_file_names(dependency_graph):
    class_names = []

    with open(dependency_graph, "r") as f:
        reader = csv.reader(f)
        for dep in reader:
            if dep[0] not in class_names:
                class_names.append(dep[0])
            if dep[1] not in class_names:
                class_names.append(dep[1])

    return class_names


# python3 run_kmeans_clustering.py [dependency graph in csv format] [ground truth architecture in rsf format] [output file name]
if __name__ == "__main__":
    dependency_graph_file = sys.argv[1]
    ground_truth_file = sys.argv[2]
    number_of_clusters = sys.argv[4]
    output_file_name = sys.argv[3]

    arch_result = run_k_means_clustering(dependency_graph_file, ground_truth_file, number_of_clusters)

    write_to_rsf_file(arch_result, output_file_name)
