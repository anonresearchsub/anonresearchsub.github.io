# Security Policy

XWiki security policy is detailed on the following document: https://dev.xwiki.org/xwiki/bin/view/Community/SecurityPolicy/.
