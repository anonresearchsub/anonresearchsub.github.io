import csv

class Utility:
    """
    This class is used to process the input data for consensus-based clustering.

    """
    def __init__(self, dependency_graph_file, consensus_group_file=None):
        self.dependency_graph = self.__read_dependency_graph(dependency_graph_file)
        if consensus_group_file is not None:
            self.consensus_group_map = self.__get_consensus_groups_map(consensus_group_file)
        else:
            self.consensus_group_map = {}


    def decontract_graph(self, contracted_clustering_result):
        decontracted_result = []
        hyper_map = {}
        consensus_group_map = self.consensus_group_map
        for e in consensus_group_map:
            if consensus_group_map[e] not in hyper_map:
                hyper_map[consensus_group_map[e]] = []
            hyper_map[consensus_group_map[e]].append(e)

        for entity in contracted_clustering_result:
            cluster, ele = entity
            if ele in hyper_map:
                for n in hyper_map[ele]:
                    decontracted_result.append(["contain", cluster, n])
            else:
                decontracted_result.append(["contain", cluster, ele])

        return decontracted_result


    def contract_graph(self):
        consensus_groups_map = self.consensus_group_map
        hyper_graph = {}
        for dep in self.dependency_graph:
            src = dep[0]
            tgt = dep[1]
            weight = float(dep[2])
            if src in consensus_groups_map:
                src = consensus_groups_map[src]
            if tgt in consensus_groups_map:
                tgt = consensus_groups_map[tgt]
            if src not in hyper_graph:
                hyper_graph[src] = {}
            if tgt not in hyper_graph[src]:
                hyper_graph[src][tgt] = [weight]
            else:
                hyper_graph[src][tgt].append(weight)

        hyper_dependency_graph = []
        for s in hyper_graph:
            for t in hyper_graph[s]:
                if s == t and hyper_graph[s][t] is None:
                    continue

                weight = max(hyper_graph[s][t])
                hyper_dependency_graph.append([s, t, float(weight)])

        return hyper_dependency_graph


    def __get_consensus_groups_map(self, consensus_group_file):
        consensus_groups = []
        with open(consensus_group_file, 'r') as group_file:
            lines = group_file.readlines()
            for line in lines:
                groupNameSeparatedFromEntities = line.split(' = ')
                [ groupName, entities ] = groupNameSeparatedFromEntities

                groupName = groupName.replace('SS(', '')
                groupName = groupName.replace(')', '')

                entities = entities.split(', ')
                for entity in entities:
                    entity = entity.replace('\n','')
                    entity = entity.split(" ")[0]
                    consensus_groups.append((groupName, entity))
        dic = {}
        for c in consensus_groups:
            group_name, ele = c
            dic[ele] = group_name

        return dic


    def __read_dependency_graph(self, dependency_graph_file):
        deps = []
        with open(dependency_graph_file, "r") as f:
            reader = csv.reader(f, delimiter=",")
            for row in reader:
                deps.append(row)
        return deps
