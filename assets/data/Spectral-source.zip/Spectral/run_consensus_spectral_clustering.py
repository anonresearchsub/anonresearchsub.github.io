import csv
import numpy as np
import argparse
from utility.Utility import Utility
from sklearn.cluster import SpectralClustering


# Global variable used for the utility class
ut = None

def run_clustering(dependency_graph, num_of_clusters, output, normalize, is_directed):
    adjacency_matrix, class_names = transform_graph_to_matrix(normalize, is_directed)

    number_of_clusters = int(num_of_clusters)

    X = np.array(adjacency_matrix)

    kmeans = SpectralClustering(n_clusters=number_of_clusters, affinity='precomputed', assign_labels="cluster_qr").fit(X)
    labels = kmeans.labels_

    decomposition = {}
    hyper_result = []
    for i, label in enumerate(labels):
        hyper_result.append((label, class_names[i]))

    result = ut.decontract_graph(hyper_result)

    with open(output +  "/" + "spectral_clustering_result.rsf", "w") as f:
        writer = csv.writer(f, delimiter=" ")
        for cluster in result:
            writer.writerow(cluster)

    return result


def normalize_dependency_graph(dependency_graph):
    all_weights = []
    copy_dep_graph = []
    for dependency in dependency_graph:
        weight = dependency[2]
        all_weights.append(weight)

    avg = np.average(all_weights)
    sigma = np.std(all_weights)

    for dependency in dependency_graph:
        weight = dependency[2]
        normalized_weight = sigmoid((weight - avg) / sigma)
        copy_dep_graph.append([dependency[0], dependency[1], normalized_weight])

    return copy_dep_graph


def retrieve_dependency_graph(dependency_graph_file):
    dependency_graph = []
    with open(dependency_graph_file, "r") as f:
        reader = csv.reader(f)
        for dep in reader:
            caller = dep[0]
            callee = dep[1]
            weight = float(dep[2])

            dependency_graph.append([caller, callee, weight])
    return dependency_graph

def convert_to_undirected_dependency_graph(dependency_graph):
    dependency_map = {}

    for dependency in dependency_graph:
        caller = dependency[0]
        callee = dependency[1]
        weight = dependency[2]

        node_pair = (caller, callee)
        node_pair_reverse = (callee, caller)

        if (node_pair in dependency_map ):
            dependency_map[node_pair] += weight
        elif (node_pair_reverse in dependency_map):
            dependency_map[node_pair_reverse] += weight
        else:
            dependency_map[node_pair] = weight

    undirected_dependency_graph = []
    for node_pair in dependency_map:
        undirected_dependency_graph.append([node_pair[0], node_pair[1], dependency_map[node_pair]])

    return undirected_dependency_graph


def transform_graph_to_matrix(normalize, is_directed):
    # contains a list of touples: [caller, callee, weight]
    dependency_graph = ut.contract_graph()

    class_names = get_all_unique_file_names(dependency_graph)

    # To ensure that we can create a symmetric adjacency matrix ->
    # convert dependency_graph into an undirected graph
    # please ensure this step occurs for the static graph

    if (is_directed):
        dependency_graph = convert_to_undirected_dependency_graph(dependency_graph)

    if (normalize):
        dependency_graph = normalize_dependency_graph(dependency_graph)

    dependency_map = {}

    for classA in class_names:
        dependency_map[classA] = {}
        for classB in class_names:
            dependency_map[classA][classB] = 0

    for dep in dependency_graph:
        caller = dep[0]
        callee = dep[1]
        weight = float(dep[2])

        # WARNING - please make sure the dependency_graph is undirected
        dependency_map[caller][callee] += weight
        dependency_map[callee][caller] += weight

    adjacency_matrix = []
    for classA in class_names:
        feature = []
        for classB in class_names:
            if classA == classB:
                feature.append(0)
            else:
                feature.append(dependency_map[classA][classB])
        adjacency_matrix.append(feature)


    return adjacency_matrix, class_names


def sigmoid(x):
    return np.exp(-np.logaddexp(0, -x))


def get_all_unique_file_names(dependency_graph):
    class_names = []
    for dep in dependency_graph:
        if dep[0] not in class_names:
            class_names.append(dep[0])
        if dep[1] not in class_names:
            class_names.append(dep[1])

    return class_names


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Consensus-based clustering for Spectral",
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("-g", "--dependency-graph", help="Dependency graph", required=True)
    parser.add_argument("-o", "--output", help="Result output destination", required=True)
    parser.add_argument("-n", "--num-of-clusters", type=int, help="Number of clusters to use in spectral clustering", required=True)
    parser.add_argument("-c", "--consensus-groups", help="A file containing the group of entities you wish to lock together during clustering. If this is not provided, then no entities are locked together", default=None)
    parser.add_argument("-r", "--normalize", type=bool, help="Normalize the graph before clustering", default=True)
    parser.add_argument("-d", "--directed", type=bool, help="The dependency graph is a directed graph", default=False)
    args = parser.parse_args()

    dependency_graph_file = args.dependency_graph
    consensus_groups = args.consensus_groups
    output_file_name = args.output
    number_of_clusters = args.num_of_clusters
    normalize = args.normalize
    is_directed = args.directed

    ut = Utility(dependency_graph_file, consensus_groups)

    architecture = run_clustering(dependency_graph_file, number_of_clusters, output_file_name, normalize, is_directed)
