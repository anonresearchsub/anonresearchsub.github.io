Apache Tomcat
Copyright 1999-2007 The Apache Software Foundation

This product includes software developed by
The Apache Software Foundation (http://www.apache.org/).

The Windows Installer is built with the Nullsoft
Scriptable Install Sysem (NSIS), which is
open source software.  The original software and
related information is available at
http://nsis.sourceforge.net.

Java compilation software for JSP pages is provided by Eclipse, 
which is open source software.  The orginal software and 
related infomation is available at
http://www.eclipse.org.

