#filter substitution
pref("app.update.channel", "@MOZ_UPDATE_CHANNEL@");
